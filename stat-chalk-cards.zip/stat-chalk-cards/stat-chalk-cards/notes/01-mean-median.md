---
num: "01"
title: 平均數與中位數
subtitle: Mean vs. Median
tag: 敘述統計
---

## 一句話

兩者都在找資料的「中心」：平均數把**每個值的大小**都算進去，中位數只看**排在正中間**的那一個；資料有極端值時，兩者就會分家。

## 比較表

| 比較 | 平均數 $\bar{x}$ | 中位數 $M$ |
|---|---|---|
| 怎麼算 | 加總 ÷ 個數 | 排序取中間 |
| 用到的資訊 | 每個值的大小 | 只看位置 |
| 受極端值影響 | [大]{粉} | [小]{綠} |
| 適合的資料 | 對稱分布 | 偏態分布 |

## 圖解

```svg
<svg viewBox="0 0 340 175" xmlns="http://www.w3.org/2000/svg">
  <text x="53.3" y="22" fill="#b5e8a8" font-size="16" text-anchor="middle">中位數 4</text>
  <line x1="53.3" y1="30" x2="53.3" y2="138" stroke="#b5e8a8" stroke-width="2" stroke-dasharray="5 4"/>
  <text x="103.3" y="62" fill="#f7a8c0" font-size="16" text-anchor="middle">平均 10</text>
  <line x1="103.3" y1="70" x2="103.3" y2="138" stroke="#f7a8c0" stroke-width="2" stroke-dasharray="5 4"/>
  <path d="M290 100 C 230 82, 160 82, 112 96" stroke="#f7a8c0" stroke-width="2" fill="none"/>
  <path d="M120 89 L112 96 L122 100" stroke="#f7a8c0" stroke-width="2" fill="none"/>
  <text x="200" y="76" fill="#f7a8c0" font-size="15" text-anchor="middle">被拉過去</text>
  <circle cx="45" cy="130" r="4.5" fill="#f5f3ec"/>
  <circle cx="45" cy="119" r="4.5" fill="#f5f3ec"/>
  <circle cx="53.3" cy="130" r="4.5" fill="#f5f3ec"/>
  <circle cx="61.7" cy="130" r="4.5" fill="#f5f3ec"/>
  <circle cx="311.7" cy="130" r="5.5" fill="#f9e27d"/>
  <text x="330" y="116" fill="#f9e27d" font-size="15" text-anchor="end">極端值 35</text>
  <line x1="14" y1="140" x2="326" y2="140" stroke="#f5f3ec" stroke-width="2.2"/>
  <g stroke="#f5f3ec" stroke-width="2">
    <line x1="20" y1="135" x2="20" y2="145"/><line x1="61.7" y1="135" x2="61.7" y2="145"/>
    <line x1="103.3" y1="135" x2="103.3" y2="145"/><line x1="145" y1="135" x2="145" y2="145"/>
    <line x1="186.7" y1="135" x2="186.7" y2="145"/><line x1="228.3" y1="135" x2="228.3" y2="145"/>
    <line x1="270" y1="135" x2="270" y2="145"/><line x1="311.7" y1="135" x2="311.7" y2="145"/>
  </g>
  <g fill="#f5f3ec" font-size="15" text-anchor="middle">
    <text x="20" y="163">0</text><text x="61.7" y="163">5</text><text x="103.3" y="163">10</text>
    <text x="145" y="163">15</text><text x="186.7" y="163">20</text><text x="228.3" y="163">25</text>
    <text x="270" y="163">30</text><text x="311.7" y="163">35</text>
  </g>
</svg>
```

月薪（萬元）：一個 35 就把平均拉到 10，中位數仍停在 4。

## 例題

5 位員工月薪（萬元）：3、3、4、5、35

1. 平均：$\bar{x}=(3+3+4+5+35)/5=50/5=10$
2. 中位數：排序後第 3 個，$M=4$
3. 5 人中有 4 人月薪不到 10 萬
4. 代表「一般人」：==報中位數 4 萬==

## 怎麼選

- **對稱分布**：兩者接近，常用平均數（後續計算方便）
- **右偏**（薪資、房價）：平均 ＞ 中位數，報 [中位數]{綠}
- **左偏**（很簡單的考試成績）：平均 ＜ 中位數
- 資料筆數是偶數：中位數取中間兩個的平均

## 常見誤解

- [✗]{粉} 「平均就是一般人的水準」→ 有極端值時，多數人可能都在平均以下。
- [✗]{粉} 「中位數就是清單正中間那個」→ 一定要**先排序**再找中間。
- [✗]{粉} 「兩者差很多一定是算錯」→ 差距大正是分布偏斜的訊號。

## 口訣

平均怕極端，中位看中間
