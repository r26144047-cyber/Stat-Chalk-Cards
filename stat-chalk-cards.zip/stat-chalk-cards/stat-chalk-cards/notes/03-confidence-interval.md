---
num: "03"
title: 信賴區間
subtitle: Confidence Interval
tag: 估計
---

## 一句話

用樣本估計母體參數時，給的不是一個數字而是一個**範圍**；95% 指的是[這種做法長期有 95% 的區間抓得到真值]{黃}。

## 直覺

1. **點估計一定有誤差**：$\bar{x}$ 幾乎不會剛好等於 $\mu$。
2. **加上誤差界限**：$\bar{x}\pm$ 誤差界限，變成一個區間。
3. **誤差看標準誤**：$s/\sqrt{n}$，樣本越大，區間越窄。
4. **信心越高越寬**：99% 的區間比 95% 的寬。

## 圖解

```svg
<svg viewBox="0 0 340 200" xmlns="http://www.w3.org/2000/svg">
  <line x1="170" y1="24" x2="170" y2="190" stroke="#f9e27d" stroke-width="2" stroke-dasharray="6 5"/>
  <text x="170" y="16" fill="#f9e27d" font-size="15" text-anchor="middle">真值 μ</text>
  <path d="M110 30 L110 38 M110 34 L210 34 M210 30 L210 38" stroke="#b5e8a8" stroke-width="2.2" fill="none"/>
  <circle cx="160" cy="34" r="3.5" fill="#b5e8a8"/>
  <path d="M132 46 L132 54 M132 50 L232 50 M232 46 L232 54" stroke="#b5e8a8" stroke-width="2.2" fill="none"/>
  <circle cx="182" cy="50" r="3.5" fill="#b5e8a8"/>
  <path d="M100 62 L100 70 M100 66 L200 66 M200 62 L200 70" stroke="#b5e8a8" stroke-width="2.2" fill="none"/>
  <circle cx="150" cy="66" r="3.5" fill="#b5e8a8"/>
  <path d="M125 78 L125 86 M125 82 L225 82 M225 78 L225 86" stroke="#b5e8a8" stroke-width="2.2" fill="none"/>
  <circle cx="175" cy="82" r="3.5" fill="#b5e8a8"/>
  <path d="M145 94 L145 102 M145 98 L245 98 M245 94 L245 102" stroke="#b5e8a8" stroke-width="2.2" fill="none"/>
  <circle cx="195" cy="98" r="3.5" fill="#b5e8a8"/>
  <path d="M118 110 L118 118 M118 114 L218 114 M218 110 L218 118" stroke="#b5e8a8" stroke-width="2.2" fill="none"/>
  <circle cx="168" cy="114" r="3.5" fill="#b5e8a8"/>
  <path d="M190 126 L190 134 M190 130 L290 130 M290 126 L290 134" stroke="#f7a8c0" stroke-width="2.2" fill="none"/>
  <circle cx="240" cy="130" r="3.5" fill="#f7a8c0"/>
  <path d="M108 142 L108 150 M108 146 L208 146 M208 142 L208 150" stroke="#b5e8a8" stroke-width="2.2" fill="none"/>
  <circle cx="158" cy="146" r="3.5" fill="#b5e8a8"/>
  <path d="M135 158 L135 166 M135 162 L235 162 M235 158 L235 166" stroke="#b5e8a8" stroke-width="2.2" fill="none"/>
  <circle cx="185" cy="162" r="3.5" fill="#b5e8a8"/>
  <path d="M122 174 L122 182 M122 178 L222 178 M222 174 L222 182" stroke="#b5e8a8" stroke-width="2.2" fill="none"/>
  <circle cx="172" cy="178" r="3.5" fill="#b5e8a8"/>
  <text x="296" y="134" fill="#f7a8c0" font-size="15" text-anchor="start">✗</text>
</svg>
```

重複抽樣 10 次：9 條抓到 μ（綠），1 條沒抓到（粉）。

## 公式

$$ \bar{x}\pm z^{*}\frac{s}{\sqrt{n}} $$

- 95% 時 $z^*=1.96$；99% 時 $z^*=2.576$
- 適用大樣本；小樣本改用 t 分布的 $t^*$

## 例題

隨機抽 100 位學生，平均每天睡 7 小時，$s=1.5$ 小時

1. 標準誤：$1.5/\sqrt{100}=0.15$
2. 誤差界限：$1.96\times0.15\approx0.29$
3. 區間：$7\pm0.29$
4. 95% 信賴區間：==(6.71, 7.29) 小時==

## 常見誤解

- [✗]{粉} 「μ 有 95% 機率在這個區間裡」→ μ 是固定值；95% 描述的是**方法**的成功率。
- [✗]{粉} 「95% 的學生睡眠落在區間內」→ 區間估的是平均數，不是個人的範圍。
- [✗]{粉} 「樣本加倍，區間減半」→ 寬度與 $\sqrt{n}$ 成反比，要 4 倍樣本才減半。

## 口訣

點估計加減誤差，九五說的是方法
