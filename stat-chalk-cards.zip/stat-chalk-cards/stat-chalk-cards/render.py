"""html/*.html  ->  png/*.png

用法：python render.py html/01-standard-deviation-圖卡.html  [--scale 2]
（不給檔名就全部輸出。依檔名尾碼決定預設倍率：
  -圖卡 ×2   → 1588×2246 px（A4 直式）
  -海報 ×2   → 3176×2246 px（A3 橫式）
  -封面 ×1.5 → 1920×1080 px（16:9）
 給 --scale 則全部改用該倍率）

HTML 本身引用 Google Fonts 與 KaTeX CDN；渲染時把這些請求導向本機 node_modules，
離線也能輸出一致的 PNG。
"""
import argparse
import mimetypes
import re
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).parent
NM = ROOT / "node_modules"
FONT_CSS = [
    "@fontsource/lxgw-wenkai-tc/400.css",
    "@fontsource/lxgw-wenkai-tc/700.css",
    "@fontsource/caveat/500.css",
    "@fontsource/caveat/700.css",
]


TW_FIX_CHARS = "U+70BA"  # 為


def iansui_fix_css():
    css = (NM / "@fontsource/iansui/400.css").read_text(encoding="utf-8")
    block = next(b for b in re.findall(r"@font-face\s*{[^}]*}", css) if "iansui-123-400" in b)
    block = re.sub(r"unicode-range:[^;]+;", f"unicode-range: {TW_FIX_CHARS};", block)
    return block.replace("url(./files/", "url(https://local.fonts/@fontsource/iansui/files/")


def local_font_css():
    out = []
    for rel in FONT_CSS:
        pkg = rel.rsplit("/", 1)[0]
        css = (NM / rel).read_text(encoding="utf-8")
        out.append(css.replace("url(./files/", f"url(https://local.fonts/{pkg}/files/"))
    return "\n".join(out)


def serve(route, path: Path):
    if path.exists():
        route.fulfill(path=str(path), content_type=mimetypes.guess_type(path.name)[0] or "application/octet-stream")
    else:
        route.abort()


SCALES = {"圖卡": 2, "海報": 2, "封面": 1.5}


def fmt_of(html: Path):
    return next((f for f in SCALES if html.stem.endswith("-" + f)), "圖卡")


def render(page, html: Path, out_dir: Path):
    page.goto(html.resolve().as_uri())
    page.wait_for_selector("body[data-ready='1']", timeout=15000)
    page.evaluate("document.fonts.ready")
    page.wait_for_timeout(300)
    over = page.evaluate("""() => {
        const els = [document.getElementById('card'), ...document.querySelectorAll('#card .grid, #card .cover, #card .sec')];
        return Math.max(...els.map(e => e.scrollHeight - e.clientHeight));
    }""")
    if over > 2:
        print(f"  ⚠ {html.name} 內容超出版面約 {over}px，請精簡筆記")
    out = out_dir / (html.stem + ".png")
    page.locator("#card").screenshot(path=str(out))
    compress(out)
    print(f"✓ {out.relative_to(ROOT)}  ({out.stat().st_size / 1e6:.1f} MB)")


def compress(png: Path):
    """用 libimagequant 量化成 256 色，檔案約縮小 70%，方便分享；沒裝就略過。"""
    try:
        import imagequant
        from PIL import Image
    except ImportError:
        return
    im = Image.open(png).convert("RGBA")
    q = imagequant.quantize_pil_image(im, dithering_level=1.0, max_colors=256, min_quality=60, max_quality=90)
    q.info.pop("transparency", None)
    q.save(png, optimize=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="*")
    ap.add_argument("--scale", type=float, default=None)
    a = ap.parse_args()
    files = [Path(f) for f in a.files] or sorted((ROOT / "html").glob("*.html"))
    out_dir = ROOT / "png"
    out_dir.mkdir(exist_ok=True)
    font_css = local_font_css()

    with sync_playwright() as p:
        browser = p.chromium.launch()
        fix_css = iansui_fix_css()
        pages = {}

        def get_page(scale):
            if scale in pages:
                return pages[scale]
            page = browser.new_page(viewport={"width": 1700, "height": 1250}, device_scale_factor=scale)
            setup_routes(page, font_css, fix_css)
            pages[scale] = page
            return page

        for f in files:
            render(get_page(a.scale or SCALES[fmt_of(f)]), f, out_dir)
        browser.close()


def setup_routes(page, font_css, fix_css):
    """字型與 KaTeX 改由 node_modules 提供，離線也能輸出一致的 PNG。"""
    page.route("https://fonts.googleapis.com/**",
               lambda r: r.fulfill(body=fix_css if "Iansui" in r.request.url else font_css,
                                   content_type="text/css"))
    page.route("https://fonts.gstatic.com/**", lambda r: r.abort())
    page.route("https://local.fonts/**",
               lambda r: serve(r, NM / r.request.url.split("local.fonts/", 1)[1]))
    page.route(re.compile(r"https://cdn\.jsdelivr\.net/npm/katex@[^/]+/(.*)"),
               lambda r: serve(r, NM / "katex" / r.request.url.split("/katex@", 1)[1].split("/", 1)[1]))


if __name__ == "__main__":
    main()
