"""notes/*.md  ->  html/NN-slug-<用途>.html  (黑板粉筆風)

用法（-f 必填，填使用者選定的用途，可多個）：
  python build.py notes/01-standard-deviation.md -f 圖卡
  python build.py notes/01-standard-deviation.md -f 圖卡 封面
  python build.py notes/01-standard-deviation.md -f 全部

用途：
  圖卡  A4 直式  794×1123   完整筆記
  海報  A3 橫式 1588×1123   完整筆記（含延伸）、三欄大字
  封面  16:9    1280×720    標題 + 一句話 + 圖解 + 口訣

筆記不必固定格式：若 layouts/NN-slug-<用途>.html 存在，就用它當版型（見 agent.md）。
"""
import argparse
import re
from pathlib import Path

import markdown
import yaml

ROOT = Path(__file__).parent
TPL = ROOT / "templates"
PARTIALS = {p.stem: p.read_text(encoding="utf-8") for p in (TPL / "partials").glob("*.html")}
PARTIALS["head"] = PARTIALS["head"].replace("{{base_css}}", (TPL / "base.css").read_text(encoding="utf-8"))

FORMATS = ("圖卡", "海報", "封面")
# 版型檔用英文檔名（避免 Windows 解壓縮時中文檔名變亂碼）；輸出檔名仍標註中文用途
TEMPLATE_FILE = {"圖卡": "card.html", "海報": "poster.html", "封面": "cover.html"}

# md 的「## 區塊名」→ CSS class
SECTIONS = {
    "一句話": "s-core",
    "直覺": "s-intuition",
    "圖解": "s-figure",
    "公式": "s-formula",
    "例題": "s-example",
    "常見誤解": "s-pitfall",
    "延伸": "s-extra",
}
GRID_ORDER = ["一句話", "直覺", "圖解", "公式", "例題", "常見誤解", "延伸"]
# 各尺寸要放哪些區塊（A4 圖卡空間有限，「延伸」只放在海報）
FORMAT_SECTIONS = {
    "圖卡": ["一句話", "直覺", "圖解", "公式", "例題", "常見誤解"],
    "海報": GRID_ORDER,
    "封面": [],  # 封面用 {{sec:…}} 自行指定
}


def protect(text):
    """把 $$..$$、$..$、```svg``` 先換成佔位符，避免 markdown 弄壞。"""
    store = []

    def keep(m):
        store.append(m.group(0) if not m.group(0).startswith("```") else m.group(1))
        return f"\x00{len(store) - 1}\x00"

    text = re.sub(r"```svg\s*\n(.*?)\n```", keep, text, flags=re.S)
    text = re.sub(r"\$\$.+?\$\$", keep, text, flags=re.S)
    text = re.sub(r"\\\[.+?\\\]", keep, text, flags=re.S)
    text = re.sub(r"\\\(.+?\\\)", keep, text, flags=re.S)
    text = re.sub(r"(?<!\\)\$[^$\n]+?\$", keep, text)
    return text, store


def restore(html, store):
    html = re.sub(r"<p>\x00(\d+)\x00</p>", lambda m: store[int(m.group(1))], html)
    return re.sub(r"\x00(\d+)\x00", lambda m: store[int(m.group(1))], html)


COLORS = {"白": "white", "黃": "yellow", "粉": "pink", "藍": "blue", "綠": "green", "橘": "orange"}


def md_to_html(text):
    text, store = protect(text)
    # [文字]{黃} → 指定粉筆色；==文字== → 黃色螢光底線
    text = re.sub(r"\[([^\]]+)\]\{(白|黃|粉|藍|綠|橘)\}",
                  lambda m: f'<span class="c-{COLORS[m.group(2)]}">{m.group(1)}</span>', text)
    text = re.sub(r"==(.+?)==", r"<mark>\1</mark>", text)
    return restore(markdown.markdown(text, extensions=["sane_lists", "tables"]), store)


def parse(md_path: Path):
    raw = md_path.read_text(encoding="utf-8")
    m = re.match(r"^---\n(.*?)\n---\n(.*)$", raw, flags=re.S)
    if not m:
        raise SystemExit(f"✗ {md_path}：缺少 front matter（--- … ---）")
    meta, body = yaml.safe_load(m.group(1)), m.group(2)
    parts = re.split(r"^##\s+(.+?)\s*$", body, flags=re.M)
    secs = {parts[i].strip(): parts[i + 1].strip() for i in range(1, len(parts), 2)}
    return meta, secs


BOX = {"黃": "box-yellow", "藍": "box-blue", "綠": "box-green", "橘": "box-orange", "粉": "box-pink", "白": "box-white"}


def section_html(name, secs, color=None, title=True):
    """任何「## 標題」都能變成一個粉筆框；標準區塊有固定色，其他區塊用 color 指定（預設白）。"""
    cls = SECTIONS.get(name, "s-free")
    if color:
        cls += " " + BOX[color]
    h2 = f"<h2>{name}</h2>" if title else ""
    return f'<section class="sec {cls}">{h2}{md_to_html(secs[name])}</section>'


def fill_slots(html, secs, src):
    """{{sec:標題}}、{{sec:標題:色}}、{{sec:標題:色:無標}}、{{md:標題}}（不加框）"""
    def sec(m):
        name, *opt = m.group(1).split(":")
        if name not in secs:
            print(f"  ⚠ {src}：筆記裡沒有「## {name}」")
            return ""
        color = opt[0] if opt and opt[0] in BOX else None
        return section_html(name, secs, color, title="無標" not in opt)

    def raw(m):
        name = m.group(1)
        if name not in secs:
            print(f"  ⚠ {src}：筆記裡沒有「## {name}」")
            return ""
        return md_to_html(secs[name])

    html = re.sub(r"\{\{sec:(.+?)\}\}", sec, html)
    return re.sub(r"\{\{md:(.+?)\}\}", raw, html)


def build(md_path: Path, formats=FORMATS):
    meta, secs = parse(md_path)
    motto = ""
    if "口訣" in secs:
        motto = f'<div class="motto"><span class="lbl">口訣</span>{md_to_html(secs["口訣"])[3:-4]}</div>'
    for fmt in formats:
        # 有自訂版面 layouts/NN-slug-<用途>.html 就用它，否則用 templates/ 的標準版型
        custom = ROOT / "layouts" / f"{md_path.stem}-{fmt}.html"
        tpl = custom if custom.exists() else TPL / TEMPLATE_FILE[fmt]
        if not custom.exists():
            unknown = set(secs) - set(SECTIONS) - {"口訣"}
            if unknown:
                print(f"  ⚠ {fmt}：標準版型沒有位置放「{'、'.join(sorted(unknown))}」"
                      f"→ 請寫 layouts/{md_path.stem}-{fmt}.html")
        names = [n for n in FORMAT_SECTIONS[fmt] if n in secs]
        body = "\n  ".join(section_html(n, secs) for n in names)
        grid_class = "has-extra" if "延伸" in names else ""
        html = tpl.read_text(encoding="utf-8")
        for k, v in PARTIALS.items():
            html = html.replace("{{" + k + "}}", v)
        html = fill_slots(html, secs, tpl.name)
        html = (html.replace("{{body}}", body).replace("{{motto}}", motto)
                    .replace("{{grid_class}}", grid_class))
        for k in ("num", "title", "subtitle", "tag"):
            html = html.replace("{{" + k + "}}", str(meta.get(k, "")))
        left = [x for x in re.findall(r"\{\{[^}]+\}\}", html) if not x.startswith("{{\\")]
        if left:
            print(f"  ⚠ 未替換的佔位符：{set(left)}")

        out = ROOT / "html" / f"{md_path.stem}-{fmt}.html"
        out.parent.mkdir(exist_ok=True)
        out.write_text(html, encoding="utf-8")
        print(f"✓ {out.relative_to(ROOT)}" + ("  （自訂版面）" if custom.exists() else ""))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="*")
    ap.add_argument("-f", "--format", nargs="+", choices=FORMATS + ("全部",), required=True,
                    help="用途：圖卡、海報、封面（可多個），或 全部")
    a = ap.parse_args()
    if "全部" in a.format:
        a.format = list(FORMATS)
    targets = [Path(p) for p in a.files] or sorted((ROOT / "notes").glob("*.md"))
    for p in targets:
        build(p, a.format)
